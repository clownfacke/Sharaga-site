document.addEventListener("DOMContentLoaded", () => {
    const taskInput = document.getElementById("task-input");
    const addBtn = document.getElementById("add-btn");
    const tasksList = document.getElementById("tasks-list");
    const itemsLeft = document.getElementById("items-left");
    const clearCompleted = document.getElementById("clear-completed");
    const filters = document.querySelectorAll(".filter-btn");
    const emptyState = document.getElementById("empty-state");

    let tasks = [];

    // Показываем текущую дату
    const dateEl = document.getElementById("date");
    const options = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
    dateEl.textContent = new Date().toLocaleDateString("ru-RU", options);

    function renderTasks(filter = "all") {
        tasksList.innerHTML = "";

        let filteredTasks = tasks;
        if (filter === "active") filteredTasks = tasks.filter(t => !t.completed);
        if (filter === "completed") filteredTasks = tasks.filter(t => t.completed);

        if (filteredTasks.length === 0) {
            emptyState.style.display = "block";
        } else {
            emptyState.style.display = "none";
        }

        filteredTasks.forEach((task, index) => {
            const taskItem = document.createElement("div");
            taskItem.classList.add("task-item");
            if (task.completed) taskItem.classList.add("completed");

            taskItem.innerHTML = `
                <input type="checkbox" ${task.completed ? "checked" : ""} class="task-checkbox">
                <span class="task-text">${task.text}</span>
                <button class="delete-btn"><i class="fas fa-trash"></i></button>
            `;

            const checkbox = taskItem.querySelector(".task-checkbox");
            const deleteBtn = taskItem.querySelector(".delete-btn");

            checkbox.addEventListener("change", () => {
                task.completed = checkbox.checked;
                renderTasks(getActiveFilter());
            });

            deleteBtn.addEventListener("click", () => {
                tasks.splice(index, 1);
                renderTasks(getActiveFilter());
            });

            tasksList.appendChild(taskItem);
        });

        updateItemsLeft();
    }

    function updateItemsLeft() {
        itemsLeft.textContent = `Всего задач: ${tasks.length}`;
    }

    function getActiveFilter() {
        return document.querySelector(".filter-btn.active").dataset.filter;
    }

    addBtn.addEventListener("click", () => {
        const text = taskInput.value.trim();
        if (text) {
            tasks.push({ text, completed: false });
            taskInput.value = "";
            renderTasks(getActiveFilter());
        }
    });

    taskInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter") addBtn.click();
    });

    filters.forEach(btn => {
        btn.addEventListener("click", () => {
            filters.forEach(b => b.classList.remove("active"));
            btn.classList.add("active");
            renderTasks(btn.dataset.filter);
        });
    });

    clearCompleted.addEventListener("click", () => {
        tasks = tasks.filter(t => !t.completed);
        renderTasks(getActiveFilter());
    });

    renderTasks();
});
